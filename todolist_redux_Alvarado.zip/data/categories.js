const CATEGORIES = [
  { id: "1", status: "Breakfast", color: "#fbd116",text:"prueba" },
  { id: "2", title: "Harinas Integrales", color: "#839791" },
  { id: "3", title: "Panes Saborizados", color: "#aac0af" },
  { id: "4", title: "Otros Productos Panaderia", color: "#896978" },
];
 
export default CATEGORIES;
